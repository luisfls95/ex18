//declaração de variáveis


window.onload = function () {
    carrega_elementos();
};


function carrega_elementos() {
    window.onkeydown = function (event) {
        processa_tecla(event)
    };
 
}

function jogar() {
	
}


function processa_tecla(event) {
  
       
}



function detecta_colisao() {
  
}

function fim_jogo() {
	
}
